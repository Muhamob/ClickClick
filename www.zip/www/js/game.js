function Game() {
}

Game.prototype. = function() {
}
